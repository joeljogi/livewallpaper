#checking requerments
check your system is x11 
only works on x11
then continue
#installing dependies
sudo apt update && sudo apt upgrade
sudo apt-get install xorg-dev build-essential libx11-dev x11proto-xext-dev libxrender-dev libxext-dev
sudo apt install intel-media-va-driver-non-free
sudo apt install unzip

#install mpv player
-------------
sudo apt update
sudo apt install mpv git build-essential libx11-dev x11-utils -y

#install xwinwrap
-------------
git clone https://github.com/ujjwal96/xwinwrap.git
cd xwinwrap
make
sudo make install
make clean
#building the system
download from https://joeljogi.github.io/livewallpaper/
cd /home/$USER/Downloads
unzip system.zip
cp  xwinwrap.service ~/.config/systemd/user/xwinwrap.service
sudo systemctl daemon-reexec              
 systemctl daemon-reload
 systemctl --user enable xwinwrap.service
 systemctl --user start xwinwrap.service
 systemctl --user  status xwinwrap.service
if any error run:  sudo loginctl enable-linger $USER
permission
----------
chmod 644 ~/.config/systemd/user/xwinwrap.service

stop live wallpaper
-----------------
sudo systemctl --user stop xwinwrap.service

bonus
----
to increase smoothness 
you need to edit the system file
nano ~/.config/systemd/user/xwinwrap.service
then change fps us you needed

when facing lag
---------------
use full HD or HD instead of 4k
check gpu usage:if gpu not using for mpv .that mean cpu is handling this task.that may slow your system and chance of increase in heat.
for any support contact me :
https://joeljogi.github.io/message/
defailt fps is 15 you can edit ... thank you




